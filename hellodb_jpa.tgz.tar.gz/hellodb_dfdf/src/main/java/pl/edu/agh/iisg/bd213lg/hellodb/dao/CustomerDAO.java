package pl.edu.agh.iisg.bd213lg.hellodb.dao;

import pl.edu.agh.iisg.bd213lg.hellodb.dao.generic.DAO;
import pl.edu.agh.iisg.bd213lg.hellodb.domain.Customer;

public interface CustomerDAO extends DAO<Customer, String> {
    

}
