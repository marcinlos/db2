package spring.hello;


public class Syso implements Printer {
    @Override
    public void print(String s) {
        System.out.println(s);
    }
}
