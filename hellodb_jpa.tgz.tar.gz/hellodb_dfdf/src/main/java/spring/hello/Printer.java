package spring.hello;

public interface Printer {
    void print(String s);
}
