package spring.hello;

public class PrinterFactory {

}
