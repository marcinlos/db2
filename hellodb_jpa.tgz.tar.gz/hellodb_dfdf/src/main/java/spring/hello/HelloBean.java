package spring.hello;

import org.springframework.beans.factory.annotation.Autowired;

public class HelloBean {

    private String greeting;

    @Autowired
    private Printer printer;
    
    public void setGreeting(String greeting) {
        this.greeting = greeting;
    }
    
    public void setPrinter(Printer printer) {
        this.printer = printer;
    }
    
    public void sayHello() {
        printer.print(greeting);
    }
}
