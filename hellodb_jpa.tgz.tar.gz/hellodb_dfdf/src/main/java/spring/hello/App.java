package spring.hello;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
        HelloBean hello = (HelloBean) ctx.getBean("helloBean");
        hello.sayHello();
        ctx.close();
    }
}
