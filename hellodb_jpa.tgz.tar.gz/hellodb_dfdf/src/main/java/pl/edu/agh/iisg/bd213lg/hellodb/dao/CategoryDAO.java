package pl.edu.agh.iisg.bd213lg.hellodb.dao;

import pl.edu.agh.iisg.bd213lg.hellodb.dao.generic.DAO;
import pl.edu.agh.iisg.bd213lg.hellodb.domain.Category;

public interface CategoryDAO extends DAO<Category, Integer> {
    
}
