package pl.edu.agh.iisg.bd213lg.hellodb.dao.generic;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DAOImplJPA<T, Id extends Serializable> implements DAO<T, Id> {

    
    private EntityManager entityManager;
    
    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Override
    public T find(Id id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Collection<T> findAll() {
        Session s = entityManager.unwrap(Session.class);
        Query q = s.createQuery("from Customer");
        return q.list();
    }

    @Override
    public Collection<T> findByExample(T example, String... excludes) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Collection<T> findByCriteria(Criterion... criterion) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean save(T entity) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean delete(T entity) {
        // TODO Auto-generated method stub
        return false;
    }

}
